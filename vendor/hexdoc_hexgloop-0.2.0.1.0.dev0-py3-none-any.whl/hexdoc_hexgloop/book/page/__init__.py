__all__ = [
    "ItemFlayPage",
    "GloopcipePage",
]

from .pages import (
    ItemFlayPage,
    GloopcipePage,
)