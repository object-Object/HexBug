def format_number(n: float) -> str:
    return f"{n:,}".replace(",", " ")
