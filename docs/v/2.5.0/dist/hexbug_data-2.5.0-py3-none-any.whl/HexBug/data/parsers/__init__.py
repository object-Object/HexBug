from .reveal import load_reveal_parser


def load_parsers():
    load_reveal_parser()
